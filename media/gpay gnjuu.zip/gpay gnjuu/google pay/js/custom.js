
    // Function to update the displayed number and provider
    // function updateDisplay() {
    //     const mobileNumber = document.getElementById("mobileNumber").value;
    //     const selectedProvider = document.querySelector('input[name="r1"]:checked').nextElementSibling.innerText;

    //     // Update the display
    //     document.getElementById("displayNumber").innerHTML = `Recharge for: ${mobileNumber}`;
    //     document.getElementById("displayProvider").innerHTML = `${selectedProvider} Prepaid`;
    // }

    // Add event listeners to update display when user types or changes provider
    // document.getElementById("mobileNumber").addEventListener("input", updateDisplay);
    // document.querySelectorAll('input[name="r1"]').forEach(radio => {
    //     radio.addEventListener("change", updateDisplay);
    // });
